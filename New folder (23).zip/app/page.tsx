"use client"

import { HeroAnimation } from "@/components/hero-animation"

export default function Home() {
  return (
    <main className="bg-black min-h-screen w-full">
      <HeroAnimation />
    </main>
  )
}

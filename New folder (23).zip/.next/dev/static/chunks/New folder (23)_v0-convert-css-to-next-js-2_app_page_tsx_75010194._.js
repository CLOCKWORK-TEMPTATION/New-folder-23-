(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/d4f58_e952cbea._.js",
  "static/chunks/New folder (23)_v0-convert-css-to-next-js-2_5b6fa14c._.js"
],
    source: "dynamic"
});

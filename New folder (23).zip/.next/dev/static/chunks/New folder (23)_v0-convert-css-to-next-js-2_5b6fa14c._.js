(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VideoTextMask",
    ()=>VideoTextMask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
const VideoTextMask = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ videoSrc, text, className = "" }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: ref,
                className: "absolute inset-0 w-full h-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                        autoPlay: true,
                        loop: true,
                        muted: true,
                        playsInline: true,
                        className: "absolute top-1/2 left-1/2 w-full h-full min-w-full min-h-full object-cover -translate-x-1/2 -translate-y-1/2",
                        style: {
                            zIndex: 1
                        },
                        src: videoSrc
                    }, void 0, false, {
                        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
                        lineNumber: 18,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-0 left-0 w-full h-full flex items-center justify-center bg-white",
                        style: {
                            zIndex: 2,
                            mixBlendMode: "screen"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-center m-0 p-0 leading-none",
                            style: {
                                fontSize: "clamp(8rem, 28vw, 40rem)",
                                fontWeight: 900,
                                color: "black",
                                fontFamily: "'Cairo', 'Noto Kufi Arabic', 'system-ui', '-apple-system', 'Segoe UI', 'Arial Black', sans-serif",
                                letterSpacing: "-0.08em",
                                fontStretch: "ultra-expanded"
                            },
                            children: text
                        }, void 0, false, {
                            fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
                            lineNumber: 36,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
                        lineNumber: 29,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
                lineNumber: 16,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 -z-10 bg-black"
            }, void 0, false, {
                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx",
        lineNumber: 14,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = VideoTextMask;
VideoTextMask.displayName = "VideoTextMask";
var _c, _c1;
__turbopack_context__.k.register(_c, "VideoTextMask$forwardRef");
__turbopack_context__.k.register(_c1, "VideoTextMask");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/New folder (23)/v0-convert-css-to-next-js-2/lib/hero-config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "heroConfig",
    ()=>heroConfig
]);
class HeroConfiguration {
    static instance;
    // Singleton Pattern: لضمان وجود نسخة واحدة فقط من الإعدادات
    constructor(){}
    static getInstance() {
        if (!HeroConfiguration.instance) {
            HeroConfiguration.instance = new HeroConfiguration();
        }
        return HeroConfiguration.instance;
    }
    // Encapsulation: حساب القيم بناءً على العرض يتم هنا فقط
    getResponsiveValues(width) {
        const isMobile = width < 768;
        const isTablet = width < 1024;
        return {
            cardWidth: isMobile ? 160 : isTablet ? 200 : 240,
            cardHeight: isMobile ? 200 : isTablet ? 250 : 300,
            fontSize: isMobile ? 48 : isTablet ? 72 : 96,
            subtitleSize: isMobile ? 18 : isTablet ? 24 : 30,
            vShapePositions: [
                {
                    top: "30%",
                    left: isMobile ? "65%" : isTablet ? "70%" : "70%",
                    rotation: 20
                },
                {
                    top: "45%",
                    left: isMobile ? "25%" : isTablet ? "75%" : "65%",
                    rotation: 15
                },
                {
                    top: "65%",
                    left: isMobile ? "35%" : isTablet ? "60%" : "60%",
                    rotation: 8
                },
                {
                    top: "75%",
                    left: "50%",
                    rotation: 0
                },
                {
                    top: "65%",
                    left: isMobile ? "65%" : isTablet ? "40%" : "40%",
                    rotation: -8
                },
                {
                    top: "45%",
                    left: isMobile ? "75%" : isTablet ? "40%" : "35%",
                    rotation: -15
                },
                {
                    top: "30%",
                    left: isMobile ? "35%" : isTablet ? "30%" : "30%",
                    rotation: -20
                }
            ]
        };
    }
}
const heroConfig = HeroConfiguration.getInstance();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/New folder (23)/v0-convert-css-to-next-js-2/hooks/use-hero-animation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useHeroAnimation",
    ()=>useHeroAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/gsap/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$ScrollTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/gsap/ScrollTrigger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$lib$2f$hero$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/lib/hero-config.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].registerPlugin(__TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$ScrollTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
const useHeroAnimation = (containerRef, triggerRef)=>{
    _s();
    const [responsiveValues, setResponsiveValues] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 1. Logic: التعامل مع تغيير حجم الشاشة
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useHeroAnimation.useEffect": ()=>{
            const handleResize = {
                "useHeroAnimation.useEffect.handleResize": ()=>{
                    const values = __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$lib$2f$hero$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["heroConfig"].getResponsiveValues(window.innerWidth);
                    setResponsiveValues(values);
                }
            }["useHeroAnimation.useEffect.handleResize"];
            handleResize();
            window.addEventListener("resize", handleResize);
            return ({
                "useHeroAnimation.useEffect": ()=>window.removeEventListener("resize", handleResize)
            })["useHeroAnimation.useEffect"];
        }
    }["useHeroAnimation.useEffect"], []);
    // 2. Logic: التعامل مع التحريك (GSAP)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "useHeroAnimation.useLayoutEffect": ()=>{
            if (!responsiveValues || !containerRef.current || !triggerRef.current) return;
            const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].context({
                "useHeroAnimation.useLayoutEffect.ctx": ()=>{
                    const tl = __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].timeline({
                        scrollTrigger: {
                            trigger: triggerRef.current,
                            start: "top top",
                            end: "+=5000",
                            scrub: 2.5,
                            pin: true,
                            anticipatePin: 1,
                            id: "hero-scroll"
                        }
                    });
                    // Phase 1: Reveal Video
                    tl.to(".video-mask-wrapper", {
                        scale: 5,
                        y: -600,
                        opacity: 0,
                        duration: 3,
                        ease: "power2.inOut",
                        pointerEvents: "none"
                    })// Phase 2: Show Fixed Header
                    .fromTo(".fixed-header", {
                        opacity: 0
                    }, {
                        opacity: 1,
                        duration: 0.8
                    }, "-=2").fromTo(".text-content-wrapper", {
                        opacity: 0,
                        y: 300,
                        scale: 0.9
                    }, {
                        opacity: 1,
                        y: -220,
                        scale: 1,
                        duration: 2,
                        ease: "power2.out",
                        zIndex: 30
                    }, "-=1.5")// Phase 3: Text Lock in Place & Cards Start Appearing
                    .to(".text-content-wrapper", {
                        y: -220,
                        duration: 1,
                        ease: "none"
                    }, 0.5);
                    // Phase 3: Card Animation Setup - Cards enter from bottom continuously
                    const phase3Images = __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].utils.toArray(".phase-3-img");
                    phase3Images.forEach({
                        "useHeroAnimation.useLayoutEffect.ctx": (img, i)=>{
                            const staggerDelay = i * 0.15;
                            const randomX = (i % 2 === 0 ? -1 : 1) * (Math.random() * 30 + 10);
                            const randomAngle = (Math.random() - 0.5) * 20;
                            tl.fromTo(img, {
                                y: "120vh",
                                rotation: randomAngle,
                                opacity: 0,
                                xPercent: randomX
                            }, {
                                y: 0,
                                opacity: 1,
                                duration: 0.8,
                                ease: "power2.out"
                            }, 1.2 + staggerDelay);
                        }
                    }["useHeroAnimation.useLayoutEffect.ctx"]);
                    // Phase 4: V-Shape Formation with smooth transition
                    tl.to(".phase-3-img", {
                        top: {
                            "useHeroAnimation.useLayoutEffect.ctx": (i)=>{
                                if (i < 7) return responsiveValues.vShapePositions[i]?.top || "50%";
                                return "100vh";
                            }
                        }["useHeroAnimation.useLayoutEffect.ctx"],
                        left: {
                            "useHeroAnimation.useLayoutEffect.ctx": (i)=>{
                                if (i < 7) return responsiveValues.vShapePositions[i]?.left || "50%";
                                return "50%";
                            }
                        }["useHeroAnimation.useLayoutEffect.ctx"],
                        xPercent: -50,
                        yPercent: -50,
                        rotation: {
                            "useHeroAnimation.useLayoutEffect.ctx": (i)=>i < 7 ? responsiveValues.vShapePositions[i]?.rotation || 0 : 0
                        }["useHeroAnimation.useLayoutEffect.ctx"],
                        scale: 0.85,
                        opacity: {
                            "useHeroAnimation.useLayoutEffect.ctx": (i)=>i < 7 ? 1 : 0
                        }["useHeroAnimation.useLayoutEffect.ctx"],
                        duration: 1.5,
                        ease: "power3.inOut"
                    }, 2);
                }
            }["useHeroAnimation.useLayoutEffect.ctx"], containerRef);
            return ({
                "useHeroAnimation.useLayoutEffect": ()=>ctx.revert()
            })["useHeroAnimation.useLayoutEffect"];
        }
    }["useHeroAnimation.useLayoutEffect"], [
        responsiveValues
    ]);
    return {
        responsiveValues
    };
};
_s(useHeroAnimation, "oxnwayG/RQPQqRhCpXGTTmKbjG8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeroAnimation",
    ()=>HeroAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$components$2f$video$2d$text$2d$mask$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/components/video-text-mask.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$hooks$2f$use$2d$hero$2d$animation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/hooks/use-hero-animation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const centerImages = [
    "https://images.unsplash.com/photo-1633356122544-f134324ef6db?w=400&h=500&fit=crop",
    "https://images.unsplash.com/photo-1571847452822-fd7d3ca5d7b7?w=400&h=500&fit=crop",
    "https://images.unsplash.com/photo-1554080221-cbf7f9a928f2?w=400&h=500&fit=crop"
];
const HeroAnimation = ()=>{
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const triggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Separation of Concerns: استدعاء المنطق من الـ Hook
    const { responsiveValues } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$hooks$2f$use$2d$hero$2d$animation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHeroAnimation"])(containerRef, triggerRef);
    // Robustness: تجنب الـ Layout Shift
    if (!responsiveValues) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-black"
    }, void 0, false, {
        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
        lineNumber: 22,
        columnNumber: 33
    }, ("TURBOPACK compile-time value", void 0));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "bg-black min-h-screen text-white",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed-header fixed top-0 left-0 right-0 h-16 bg-black/90 backdrop-blur-sm border-b border-white/10 z-[100] opacity-0 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "font-bold text-sm md:text-base lg:text-xl tracking-widest text-white/80",
                    children: "النسخة"
                }, void 0, false, {
                    fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: triggerRef,
                className: "h-screen w-full relative overflow-hidden flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "video-mask-wrapper absolute inset-0 z-50 bg-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$components$2f$video$2d$text$2d$mask$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VideoTextMask"], {
                            videoSrc: "https://cdn.pixabay.com/video/2025/11/09/314880.mp4",
                            text: "النسخة",
                            className: "w-full h-full"
                        }, void 0, false, {
                            fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "main-content-wrapper relative z-40 flex flex-col items-center justify-center text-center w-full h-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-content-wrapper flex flex-col items-center justify-center w-auto max-w-4xl gap-2 md:gap-3 lg:gap-4 z-30 p-4 md:p-6 lg:p-10 bg-black/20 backdrop-blur-sm rounded-2xl md:rounded-3xl border border-white/10 -ml-7",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-main text-4xl sm:text-5xl md:text-7xl lg:text-9xl font-black tracking-tighter leading-tight text-center",
                                    children: "بس اصلي"
                                }, void 0, false, {
                                    fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                                    lineNumber: 47,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-dedication text-lg sm:text-xl md:text-2xl lg:text-3xl font-light text-dedication-color mt-1 md:mt-2 text-center",
                                    children: "اهداء ليسري نصر الله"
                                }, void 0, false, {
                                    fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    [
                        ...Array(7)
                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "phase-3-img absolute rounded-lg shadow-2xl overflow-hidden border border-white/20 z-20",
                            style: {
                                width: `${responsiveValues.cardWidth}px`,
                                height: `${responsiveValues.cardHeight}px`,
                                left: `${40 + (i - 3) * 8}%`,
                                top: "100%",
                                transform: "translateX(-50%)"
                            },
                            children: i >= 2 && i <= 4 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full h-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: centerImages[i - 2] || "/placeholder.svg",
                                    alt: `Scene ${i}`,
                                    fill: true,
                                    sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                                    className: "object-cover",
                                    priority: true
                                }, void 0, false, {
                                    fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                                    lineNumber: 72,
                                    columnNumber: 18
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full h-full bg-gradient-to-br from-white/5 to-white/0 border border-white/10"
                            }, void 0, false, {
                                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                                lineNumber: 82,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, `p3-${i}`, false, {
                            fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)))
                ]
            }, void 0, true, {
                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-10 left-1/2 -translate-x-1/2 z-50 animate-bounce text-white/50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M12 5v14M19 12l-7 7-7-7"
                    }, void 0, false, {
                        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                    lineNumber: 89,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(HeroAnimation, "L9TSjlbwOI5or+R88W5Q+VXpJj4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$hooks$2f$use$2d$hero$2d$animation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHeroAnimation"]
    ];
});
_c = HeroAnimation;
var _c;
__turbopack_context__.k.register(_c, "HeroAnimation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/New folder (23)/v0-convert-css-to-next-js-2/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$components$2f$hero$2d$animation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/New folder (23)/v0-convert-css-to-next-js-2/components/hero-animation.tsx [app-client] (ecmascript)");
"use client";
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "bg-black min-h-screen w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$New__folder__$28$23$292f$v0$2d$convert$2d$css$2d$to$2d$next$2d$js$2d$2$2f$components$2f$hero$2d$animation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeroAnimation"], {}, void 0, false, {
            fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/app/page.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/New folder (23)/v0-convert-css-to-next-js-2/app/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=New%20folder%20%2823%29_v0-convert-css-to-next-js-2_5b6fa14c._.js.map
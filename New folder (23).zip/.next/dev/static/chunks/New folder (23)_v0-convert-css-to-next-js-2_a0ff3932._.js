(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1cea921f._.js",
  "static/chunks/d4f58_next_dist_compiled_react-dom_483ed13a._.js",
  "static/chunks/d4f58_next_dist_compiled_react-server-dom-turbopack_fe7470d3._.js",
  "static/chunks/d4f58_next_dist_compiled_next-devtools_index_3442f570.js",
  "static/chunks/d4f58_next_dist_compiled_3e1e7b44._.js",
  "static/chunks/d4f58_next_dist_client_2a22b11b._.js",
  "static/chunks/d4f58_next_dist_c92a3873._.js",
  "static/chunks/d4f58_@swc_helpers_cjs_34a7cd80._.js"
],
    source: "entry"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__df0c23fd._.css",
  "static/chunks/d4f58_79d91a8d._.js"
],
    source: "dynamic"
});

module.exports = [
"[project]/New folder (23)/v0-convert-css-to-next-js-2/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=86618_v0-convert-css-to-next-js-2__next-internal_server_app_page_actions_703b8cae.js.map
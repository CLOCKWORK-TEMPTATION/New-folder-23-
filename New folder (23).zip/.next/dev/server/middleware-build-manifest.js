globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/d4f58_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1cea921f._.js",
    "static/chunks/d4f58_next_dist_compiled_react-dom_483ed13a._.js",
    "static/chunks/d4f58_next_dist_compiled_react-server-dom-turbopack_fe7470d3._.js",
    "static/chunks/d4f58_next_dist_compiled_next-devtools_index_3442f570.js",
    "static/chunks/d4f58_next_dist_compiled_3e1e7b44._.js",
    "static/chunks/d4f58_next_dist_client_2a22b11b._.js",
    "static/chunks/d4f58_next_dist_c92a3873._.js",
    "static/chunks/d4f58_@swc_helpers_cjs_34a7cd80._.js",
    "static/chunks/New folder (23)_v0-convert-css-to-next-js-2_a0ff3932._.js",
    "static/chunks/turbopack-New folder (23)_v0-convert-css-to-next-js-2_657555f4._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];